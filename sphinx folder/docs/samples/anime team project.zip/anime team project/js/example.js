// Step 2: Select the element to animate
  // Select the HTML element with the class '.circle'
  var circle = document.querySelector('.circle');

  // Step 3: Define the animation
  // Define the animation properties using Anime.js
  var animation = anime({
    targets: '.circle',
    scale: [1, 1.2], // Step 4: Scale the circle from its original size to 20% larger
    duration: 1000, // Step 5: Animation duration in milliseconds
    loop: true, // Step 6: Enable looping to create a pulsating effect
    direction: 'alternate', // Step 7: Reverse animation direction to create pulsating effect
    easing: 'easeInOutQuad' // Step 8: Easing function for smooth animation
  });