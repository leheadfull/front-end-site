// Select all boxes -- first animation
const box = document.querySelectorAll('.Topbox');
    
// Define animation properties
const animation = anime({
  targets: box,
  translateY: [
    { value: 100, duration: 500 },
    { value: 0, duration: 800 }
  ],
  opacity: [
    { value: 0, duration: 500 },
    { value: 1, duration: 800 }
  ],
  delay: anime.stagger(100) // Stagger the animation
});

//second animation
anime({
    targets: '.Numberbox', // Targets elements with the class "box"
    translateX: 500, // Horizontal translation
    delay: anime.stagger(500), // Stagger the animation with a delay for each element
    duration: 1000, // Animation duration (in milliseconds)
    easing: 'easeInOutSine', // Animation easing function
    loop: true // Loop the animation
  });

//third animation
anime({
    targets: '.Stringbox', // Targets elements with the class "box"
    borderRadius: anime.stagger('25%'), // Animates the borderRadius property with stagger effect
    duration: 1000, // Animation duration (in milliseconds)
    easing: 'easeInOutSine', // Animation easing function
    loop: true // Loop the animation
  });

//last animation
anime({
    targets: '.Arraybox', // Targets elements with the class "box"
    translateX: anime.stagger([50, 250]), // Animates horizontal translation
    duration: 1000, // Animation duration (in milliseconds)
    easing: 'easeInOutSine', // Animation easing function
    loop: true // Loop the animation
  });